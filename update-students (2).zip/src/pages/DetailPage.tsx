import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Header } from '../components/Header';
import { UpdateData } from '../components/UpdateCard';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { ArrowLeft, Calendar, Building2, Users, MapPin, Bookmark, Share2, ImageIcon } from 'lucide-react';
import { motion } from 'framer-motion';
import { useBookmarkContext } from '../contexts/BookmarkContext';
import { cn, formatDate } from '../contexts/utils';

export function DetailPage() {
  const { id } = useParams<{ id: string }>();
  const [update, setUpdate] = useState<UpdateData | null>(null);
  const [loading, setLoading] = useState(true);
  const { bookmarks, toggleBookmark, isAuthenticated } = useBookmarkContext();
  const isBookmarked = id ? bookmarks[id] : false;

  const handleShare = async () => {
    if (!update) return;
    
    const shareData = {
      title: update.title,
      text: `Check out this update: ${update.title} from ${update.organization}`,
      url: window.location.href,
    };

    if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        console.error('Error sharing:', err);
      }
    } else {
      // Fallback: Copy to clipboard
      try {
        await navigator.clipboard.writeText(shareData.url);
        alert('Link copied to clipboard!');
      } catch (err) {
        console.error('Failed to copy:', err);
      }
    }
  };

  useEffect(() => {
    const fetchUpdate = async () => {
      if (!id) return;
      try {
        const docRef = doc(db, 'updates', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setUpdate({ id: docSnap.id, ...docSnap.data() } as UpdateData);
        } else {
          console.log("No such document!");
        }
      } catch (error) {
        console.error("Error fetching document:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchUpdate();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 font-sans">
        <Header />
        <div className="flex justify-center items-center h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-academic-blue"></div>
        </div>
      </div>
    );
  }

  if (!update) {
    return (
      <div className="min-h-screen bg-slate-50 font-sans">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <h2 className="text-2xl font-bold text-slate-700 mb-4">Update not found</h2>
          <Link to="/" className="text-academic-blue hover:underline">Return to Home</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 py-8 pb-20">
        <Link to="/" className="inline-flex items-center gap-2 text-slate-500 hover:text-academic-blue transition-colors mb-6">
          <ArrowLeft size={20} />
          <span>Back to Updates</span>
        </Link>

        <motion.article 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden"
        >
          {update.thumbnail && (
            <div className="w-full h-64 md:h-96 overflow-hidden border-b border-slate-100">
              <img 
                src={update.thumbnail} 
                alt={update.title} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          )}

          <div className="p-6 md:p-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-red-600"></span>
                <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-red-600 leading-tight">
                  {update.title}
                </h1>
              </div>
              <div className="flex items-center gap-2 self-start md:self-center">
                {isAuthenticated && (
                  <button
                    onClick={() => toggleBookmark(update)}
                    className={cn(
                      "flex items-center gap-2 px-4 py-2 rounded-full border transition-all duration-200 shadow-sm shrink-0",
                      isBookmarked 
                        ? "bg-academic-gold text-white border-academic-gold" 
                        : "bg-white text-slate-600 border-slate-200 hover:border-academic-gold hover:text-academic-gold"
                    )}
                  >
                    <Bookmark size={20} fill={isBookmarked ? "currentColor" : "none"} />
                    <span className="font-semibold">{isBookmarked ? "Saved" : "Save"}</span>
                  </button>
                )}
                <button
                  onClick={handleShare}
                  className="flex items-center gap-2 px-4 py-2 rounded-full border border-slate-200 bg-white text-slate-600 hover:border-academic-blue hover:text-academic-blue transition-all duration-200 shadow-sm shrink-0"
                  title="Share Update"
                >
                  <Share2 size={20} />
                  <span className="font-semibold">Share</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8 bg-slate-50 p-4 rounded-lg border border-slate-100">
              <div className="flex items-center gap-3 text-slate-700">
                <Building2 className="text-academic-blue" size={20} />
                <div>
                  <p className="text-xs text-slate-500 uppercase font-semibold tracking-wider">Organization</p>
                  <p className="font-medium">{update.organization}</p>
                </div>
              </div>
              
              {update.posts !== undefined && (
                <div className="flex items-center gap-3 text-slate-700">
                  <Users className="text-academic-blue" size={20} />
                  <div>
                    <p className="text-xs text-slate-500 uppercase font-semibold tracking-wider">Total Posts</p>
                    <p className="font-medium">{update.posts}</p>
                  </div>
                </div>
              )}

              <div className="flex items-center gap-3 text-slate-700">
                <MapPin className="text-academic-blue" size={20} />
                <div>
                  <p className="text-xs text-slate-500 uppercase font-semibold tracking-wider">State / Region</p>
                  <p className="font-medium">{update.state}</p>
                </div>
              </div>

              <div className="flex items-center gap-3 text-slate-700">
                <Calendar className="text-academic-blue" size={20} />
                <div>
                  <p className="text-xs text-slate-500 uppercase font-semibold tracking-wider">Important Dates</p>
                  <div className="text-sm font-medium">
                    {update.type === 'job' ? (
                      <>
                        {update.startDate && <p>Start: {formatDate(update.startDate)}</p>}
                        {update.endDate && <p>End: {formatDate(update.endDate)}</p>}
                        {update.updateDate && <p>Last Updated: {formatDate(update.updateDate)}</p>}
                      </>
                    ) : (
                      <p>Release: {formatDate(update.releaseDate)}</p>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="prose prose-slate max-w-none mb-8">
              <h2 className="text-xl font-bold text-academic-blue mb-4 border-b pb-2">Details</h2>
              <p className="whitespace-pre-wrap text-slate-700 leading-relaxed">
                {update.description}
              </p>
            </div>

            {update.steps && update.steps.length > 0 && (
              <div className="mb-12">
                <h2 className="text-2xl font-bold text-academic-blue mb-6 flex items-center gap-2">
                  <span className="p-2 bg-blue-50 rounded-lg">
                    <ImageIcon size={24} />
                  </span>
                  Step-by-Step Application Guide
                </h2>
                
                <div className="space-y-0 relative">
                  {/* Vertical line that spans all steps */}
                  <div className="absolute left-[15px] top-4 bottom-4 w-0.5 bg-slate-100 hidden md:block"></div>
                  
                  {update.steps.map((step, index) => (
                    <div key={index} className="relative pl-0 md:pl-12 pb-12 last:pb-0">
                      <div className="absolute left-0 md:left-[0px] top-0 w-8 h-8 bg-academic-blue text-white rounded-full flex items-center justify-center font-bold shadow-md z-10">
                        {index + 1}
                      </div>
                      
                      <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 shadow-sm ml-10 md:ml-0">
                        <p className="text-slate-700 leading-relaxed mb-6 font-medium">
                          {step.text}
                        </p>
                        
                        {step.image && (
                          <div className="rounded-xl overflow-hidden border border-slate-200 shadow-lg bg-white">
                            <img 
                              src={step.image} 
                              alt={`Step ${index + 1}`} 
                              className="w-full h-auto"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {update.ageLimit && (
              <div className="bg-blue-50 border border-blue-100 rounded-lg p-6 mb-8">
                <h3 className="text-lg font-bold text-academic-blue mb-2 flex items-center gap-2">
                  Age Limit
                </h3>
                <p className="text-slate-700 whitespace-pre-wrap">
                  {update.ageLimit}
                </p>
              </div>
            )}
            
            <div className="mt-8 pt-6 border-t border-slate-200 flex justify-center">
               {update.officialUrl ? (
                 <a 
                   href={update.officialUrl} 
                   target="_blank" 
                   rel="noopener noreferrer"
                   className="bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-8 rounded-full shadow-md transition-transform hover:scale-105 active:scale-95 inline-block text-center"
                 >
                   Apply / View Official Notice
                 </a>
               ) : (
                 <button 
                   onClick={() => alert('Please check the official website of the organization for the notice.')}
                   className="bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-8 rounded-full shadow-md transition-transform hover:scale-105 active:scale-95"
                 >
                   Apply / View Official Notice
                 </button>
               )}
            </div>
          </div>
        </motion.article>
      </main>
    </div>
  );
}
