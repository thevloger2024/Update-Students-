import React, { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { auth, db } from '../firebase';
import { collection, addDoc, serverTimestamp, query, orderBy, limit, getDocs, deleteDoc, doc, updateDoc, writeBatch } from 'firebase/firestore';
import { onAuthStateChanged, User } from 'firebase/auth';
import { Plus, Trash2, LayoutDashboard, Briefcase, FileText, CheckCircle, Save, AlertCircle, Search, Filter, ArrowUpDown, ArrowUp, ArrowDown, ExternalLink, Lock, LogIn, LogOut, Settings, Shield, Star, CheckSquare, Square, Edit, X, Image as ImageIcon, PlusCircle, MinusCircle, Upload, ChevronRight, ChevronDown, Eye } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';
import { signInWithGoogle, logOut } from '../firebase';
import { formatDate } from '../contexts/utils';

const ADMIN_EMAIL = "thevloger2024@gmail.com";

interface UpdateForm {
  title: string;
  type: 'job' | 'admit_card' | 'result' | 'scholarship';
  category: string;
  state: string;
  organization: string;
  description: string;
  startDate?: string;
  endDate?: string;
  updateDate?: string;
  releaseDate?: string;
  posts?: number;
  ageLimit?: string;
  officialUrl?: string;
  featured: boolean;
  thumbnail?: string;
  steps?: {
    text: string;
    image?: string;
  }[];
}

const INITIAL_FORM: UpdateForm = {
  title: '',
  type: 'job',
  category: '',
  state: '',
  organization: '',
  description: '',
  startDate: '',
  endDate: '',
  updateDate: '',
  releaseDate: '',
  posts: undefined,
  ageLimit: '',
  officialUrl: '',
  featured: false,
  thumbnail: '',
  steps: [],
};

export function AdminPage() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [isBatchDelete, setIsBatchDelete] = useState(false);
  const [form, setForm] = useState<UpdateForm>(INITIAL_FORM);
  const [updates, setUpdates] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [sortField, setSortField] = useState<string>('createdAt');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser && currentUser.email === ADMIN_EMAIL) {
        fetchUpdates();
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const fetchUpdates = async () => {
    try {
      const q = query(collection(db, 'updates'), orderBy('createdAt', 'desc'));
      const querySnapshot = await getDocs(q);
      const data = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setUpdates(data);
    } catch (error) {
      console.error("Error fetching updates:", error);
    }
  };

  const filteredAndSortedUpdates = updates
    .filter(update => {
      const matchesSearch = update.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          update.organization.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          update.category.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesType = filterType === 'all' || update.type === filterType;
      return matchesSearch && matchesType;
    })
    .sort((a, b) => {
      const aValue = a[sortField];
      const bValue = b[sortField];
      
      if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });

  const toggleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === filteredAndSortedUpdates.length && filteredAndSortedUpdates.length > 0) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredAndSortedUpdates.map(u => u.id));
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) 
        ? prev.filter(i => i !== id) 
        : [...prev, id]
    );
  };

  const handleBatchDelete = () => {
    if (selectedIds.length === 0) return;
    setIsBatchDelete(true);
    setDeleteId(null);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    setSubmitting(true);
    try {
      if (isBatchDelete) {
        const batch = writeBatch(db);
        selectedIds.forEach(id => {
          batch.delete(doc(db, 'updates', id));
        });
        await batch.commit();
        toast.success(`${selectedIds.length} updates deleted successfully!`);
        setSelectedIds([]);
      } else if (deleteId) {
        await deleteDoc(doc(db, 'updates', deleteId));
        toast.success("Update deleted");
      }
      fetchUpdates();
    } catch (error) {
      console.error("Error deleting:", error);
      toast.error("Failed to delete");
    } finally {
      setSubmitting(false);
      setShowDeleteConfirm(false);
      setDeleteId(null);
      setIsBatchDelete(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    setSubmitting(true);
    try {
      // Prepare form data: handle numeric conversion and ensure optional fields are handled correctly
      const updateData = {
        ...form,
        posts: form.posts ? Number(form.posts) : null,
        updatedAt: Date.now(),
      };

      if (editingId) {
        await updateDoc(doc(db, 'updates', editingId), updateData);
        toast.success("Update modified successfully!");
      } else {
        await addDoc(collection(db, 'updates'), {
          ...updateData,
          createdAt: Date.now(),
        });
        toast.success("Update published successfully!");
      }
      
      setForm(INITIAL_FORM);
      setEditingId(null);
      fetchUpdates();
    } catch (error) {
      console.error("Error publishing update:", error);
      toast.error("Failed to publish update. Check console for details.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleEdit = (update: any) => {
    setEditingId(update.id);
    setForm({
      title: update.title || '',
      type: update.type || 'job',
      category: update.category || '',
      state: update.state || '',
      organization: update.organization || '',
      description: update.description || '',
      startDate: update.startDate || '',
      endDate: update.endDate || '',
      updateDate: update.updateDate || '',
      releaseDate: update.releaseDate || '',
      posts: update.posts,
      ageLimit: update.ageLimit || '',
      officialUrl: update.officialUrl || '',
      featured: !!update.featured,
      thumbnail: update.thumbnail || '',
      steps: update.steps || [],
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setForm(INITIAL_FORM);
  };

  const compressImage = (file: File, maxWidth = 800, quality = 0.7): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target?.result as string;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;

          if (width > maxWidth) {
            height = (maxWidth / width) * height;
            width = maxWidth;
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', quality));
        };
        img.onerror = (err) => reject(err);
      };
      reader.onerror = (err) => reject(err);
    });
  };

  const handleThumbnailUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    try {
      const compressed = await compressImage(file, 1200, 0.6);
      setForm(prev => ({ ...prev, thumbnail: compressed }));
      toast.success("Thumbnail uploaded");
    } catch (error) {
      toast.error("Failed to process image");
    }
  };

  const handleStepImageUpload = async (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    try {
      const compressed = await compressImage(file, 800, 0.6);
      const newSteps = [...(form.steps || [])];
      newSteps[index] = { ...newSteps[index], image: compressed };
      setForm(prev => ({ ...prev, steps: newSteps }));
      toast.success(`Step ${index + 1} image uploaded`);
    } catch (error) {
      toast.error("Failed to process image");
    }
  };

  const addStep = () => {
    setForm(prev => ({
      ...prev,
      steps: [...(prev.steps || []), { text: '', image: '' }]
    }));
  };

  const removeStep = (index: number) => {
    setForm(prev => ({
      ...prev,
      steps: (prev.steps || []).filter((_, i) => i !== index)
    }));
  };

  const moveStep = (index: number, direction: 'up' | 'down') => {
    const steps = [...(form.steps || [])];
    if (direction === 'up' && index > 0) {
      [steps[index], steps[index - 1]] = [steps[index - 1], steps[index]];
    } else if (direction === 'down' && index < steps.length - 1) {
      [steps[index], steps[index + 1]] = [steps[index + 1], steps[index]];
    }
    setForm(prev => ({ ...prev, steps }));
  };

  const updateStepText = (index: number, text: string) => {
    const newSteps = [...(form.steps || [])];
    newSteps[index] = { ...newSteps[index], text };
    setForm(prev => ({ ...prev, steps: newSteps }));
  };

  const handleDelete = (id: string) => {
    setDeleteId(id);
    setIsBatchDelete(false);
    setShowDeleteConfirm(true);
  };

  const handleToggleFeatured = async (id: string, currentStatus: boolean) => {
    try {
      await updateDoc(doc(db, 'updates', id), {
        featured: !currentStatus
      });
      toast.success(`Update ${!currentStatus ? 'marked as featured' : 'removed from featured'}`);
      fetchUpdates();
    } catch (error) {
      toast.error("Failed to update featured status");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-academic-blue"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 rounded-3xl shadow-xl border border-slate-200 max-w-md w-full text-center"
        >
          <div className="w-20 h-20 bg-blue-50 text-academic-blue rounded-full flex items-center justify-center mx-auto mb-6">
            <Lock size={40} />
          </div>
          <h1 className="text-2xl font-serif font-bold text-academic-blue mb-2">Admin Login</h1>
          <p className="text-slate-500 mb-8">Please sign in with your administrator account to access this panel.</p>
          <button 
            onClick={signInWithGoogle}
            className="w-full bg-academic-blue hover:bg-blue-800 text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-100 flex items-center justify-center gap-3 transition-all active:scale-95"
          >
            <LogIn size={20} />
            <span>Sign in with Google</span>
          </button>
        </motion.div>
      </div>
    );
  }

  if (user.email !== ADMIN_EMAIL) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 rounded-3xl shadow-xl border border-slate-200 max-w-md w-full text-center"
        >
          <div className="w-20 h-20 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <Shield size={40} className="text-red-500" />
          </div>
          <h1 className="text-2xl font-serif font-bold text-red-600 mb-2">Access Denied</h1>
          <p className="text-slate-500 mb-8">
            The account <span className="font-bold text-slate-800">{user.email}</span> does not have administrator privileges.
          </p>
          <div className="space-y-4">
            <button 
              onClick={logOut}
              className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-4 rounded-2xl flex items-center justify-center gap-3 transition-all active:scale-95"
            >
              <LogOut size={20} />
              <span>Sign out</span>
            </button>
            <button 
              onClick={() => navigate('/')}
              className="w-full text-academic-blue font-bold py-2 hover:underline transition-all"
            >
              Back to Home
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="p-3 bg-academic-blue text-white rounded-2xl">
            <LayoutDashboard size={28} />
          </div>
          <div>
            <h1 className="text-3xl font-serif font-bold text-academic-blue">Admin Dashboard</h1>
            <p className="text-slate-500">Manage site content and updates</p>
          </div>
          <button 
            onClick={() => navigate('/admin/features')}
            className="ml-auto flex items-center gap-2 bg-white border-2 border-academic-blue/10 text-academic-blue px-6 py-3 rounded-2xl font-bold hover:bg-academic-blue hover:text-white transition-all shadow-sm active:scale-95"
          >
            <Settings size={20} />
            <span>Admin Features</span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Form Section */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-200">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                  {editingId ? <Edit size={20} className="text-academic-blue" /> : <Plus size={20} className="text-academic-blue" />}
                  {editingId ? 'Edit Update' : 'Add New Update'}
                </h2>
                {editingId && (
                  <button 
                    onClick={handleCancelEdit}
                    className="text-sm font-bold text-slate-400 hover:text-red-500 flex items-center gap-1 transition-colors"
                  >
                    <X size={16} />
                    Cancel Edit
                  </button>
                )}
              </div>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-600 uppercase tracking-wider">Title</label>
                    <input 
                      required
                      type="text"
                      placeholder="e.g. RRB NTPC Recruitment 2024"
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-academic-blue outline-none transition-all"
                      value={form.title}
                      onChange={e => setForm({...form, title: e.target.value})}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-600 uppercase tracking-wider">Thumbnail Image (Optional)</label>
                    <div className="flex items-center gap-4">
                      <div className="relative w-full">
                        <input 
                          type="file"
                          accept="image/*"
                          onChange={handleThumbnailUpload}
                          className="hidden"
                          id="thumbnail-upload"
                        />
                        <label 
                          htmlFor="thumbnail-upload"
                          className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl border-2 border-dashed border-slate-200 hover:border-academic-blue hover:bg-blue-50 cursor-pointer transition-all"
                        >
                          <Upload size={18} className="text-slate-400" />
                          <span className="text-sm text-slate-600 font-medium">
                            {form.thumbnail ? 'Change Thumbnail' : 'Upload Thumbnail'}
                          </span>
                        </label>
                      </div>
                      {form.thumbnail && (
                        <div className="relative w-16 h-16 rounded-lg overflow-hidden border border-slate-200 shrink-0">
                          <img src={form.thumbnail} alt="Thumbnail" className="w-full h-full object-cover" />
                          <button 
                            type="button"
                            onClick={() => setForm(prev => ({ ...prev, thumbnail: '' }))}
                            className="absolute top-0 right-0 bg-red-500 text-white p-0.5 rounded-bl-lg"
                          >
                            <X size={12} />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-600 uppercase tracking-wider">Type</label>
                    <select 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-academic-blue outline-none transition-all bg-white"
                      value={form.type}
                      onChange={e => setForm({...form, type: e.target.value as any})}
                    >
                      <option value="job">Job Update</option>
                      <option value="admit_card">Admit Card</option>
                      <option value="result">Result</option>
                      <option value="scholarship">Scholarship</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-600 uppercase tracking-wider">Category</label>
                    <select 
                      required
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-academic-blue outline-none transition-all bg-white"
                      value={form.category}
                      onChange={e => setForm({...form, category: e.target.value})}
                    >
                      <option value="">Select Category</option>
                      <option value="RRB">RRB</option>
                      <option value="SSC">SSC</option>
                      <option value="UPSC">UPSC</option>
                      <option value="Banking">Banking</option>
                      <option value="Railway">Railway</option>
                      <option value="Police">Police</option>
                      <option value="Teaching">Teaching</option>
                      <option value="Defence">Defence</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-600 uppercase tracking-wider">State / Region</label>
                    <input 
                      required
                      type="text"
                      placeholder="e.g. All India, Bihar"
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-academic-blue outline-none transition-all"
                      value={form.state}
                      onChange={e => setForm({...form, state: e.target.value})}
                    />
                    <p className="text-[10px] text-slate-400 italic">Type "all" to show this update for all states.</p>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-600 uppercase tracking-wider">Organization</label>
                    <input 
                      required
                      type="text"
                      placeholder="e.g. Railway Recruitment Board"
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-academic-blue outline-none transition-all"
                      value={form.organization}
                      onChange={e => setForm({...form, organization: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-600 uppercase tracking-wider">Total Posts (Optional)</label>
                    <input 
                      type="number"
                      placeholder="e.g. 1200"
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-academic-blue outline-none transition-all"
                      value={form.posts || ''}
                      onChange={e => setForm({...form, posts: e.target.value ? Number(e.target.value) : undefined})}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-600 uppercase tracking-wider">Description / Details</label>
                  <textarea 
                    required
                    rows={4}
                    placeholder="Full details about the update..."
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-academic-blue outline-none transition-all resize-none"
                    value={form.description}
                    onChange={e => setForm({...form, description: e.target.value})}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-600 uppercase tracking-wider">Official URL</label>
                    <input 
                      type="url"
                      placeholder="https://..."
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-academic-blue outline-none transition-all"
                      value={form.officialUrl || ''}
                      onChange={e => setForm({...form, officialUrl: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-600 uppercase tracking-wider">Age Limit</label>
                    <input 
                      type="text"
                      placeholder="e.g. 18-30 Years"
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-academic-blue outline-none transition-all"
                      value={form.ageLimit || ''}
                      onChange={e => setForm({...form, ageLimit: e.target.value})}
                    />
                  </div>
                </div>

                {/* Step-by-Step Guide Section */}
                <div className="space-y-4 pt-4 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                      <ImageIcon size={20} className="text-academic-blue" />
                      Step-by-Step Guide (Optional)
                    </h3>
                    <div className="flex items-center gap-4">
                      {form.steps && form.steps.length > 0 && (
                        <button 
                          type="button"
                          onClick={() => setShowPreview(true)}
                          className="flex items-center gap-2 text-sm font-bold text-slate-500 hover:text-academic-blue transition-colors"
                        >
                          <Eye size={18} />
                          Preview Guide
                        </button>
                      )}
                      <button 
                        type="button"
                        onClick={addStep}
                        className="flex items-center gap-2 text-sm font-bold text-academic-blue hover:text-blue-800 transition-colors"
                      >
                        <PlusCircle size={18} />
                        Add Step
                      </button>
                    </div>
                  </div>
                  
                  <div className="space-y-6">
                    {form.steps?.map((step, index) => (
                      <motion.div 
                        key={index}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="p-6 bg-slate-50 rounded-2xl border border-slate-200 relative group"
                      >
                        <button 
                          type="button"
                          onClick={() => removeStep(index)}
                          className="absolute -top-2 -right-2 bg-red-500 text-white p-1.5 rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <MinusCircle size={16} />
                        </button>
                        
                        <div className="flex items-center gap-3 mb-4">
                          <span className="w-8 h-8 bg-academic-blue text-white rounded-full flex items-center justify-center font-bold text-sm">
                            {index + 1}
                          </span>
                          <h4 className="font-bold text-slate-700">Step {index + 1} Instructions</h4>
                          
                          <div className="flex items-center gap-1 ml-auto mr-8">
                            <button
                              type="button"
                              onClick={() => moveStep(index, 'up')}
                              disabled={index === 0}
                              className="p-1.5 text-slate-400 hover:text-academic-blue hover:bg-blue-50 rounded-lg transition-all disabled:opacity-20 disabled:cursor-not-allowed"
                              title="Move Up"
                            >
                              <ArrowUp size={16} />
                            </button>
                            <button
                              type="button"
                              onClick={() => moveStep(index, 'down')}
                              disabled={index === (form.steps?.length || 0) - 1}
                              className="p-1.5 text-slate-400 hover:text-academic-blue hover:bg-blue-50 rounded-lg transition-all disabled:opacity-20 disabled:cursor-not-allowed"
                              title="Move Down"
                            >
                              <ArrowDown size={16} />
                            </button>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase">Instructions</label>
                            <textarea 
                              rows={3}
                              placeholder="Describe what to do in this step..."
                              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-academic-blue outline-none transition-all resize-none bg-white"
                              value={step.text}
                              onChange={e => updateStepText(index, e.target.value)}
                            />
                          </div>
                          
                          <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase">Step Image</label>
                            <div className="flex items-center gap-4">
                              <div className="relative w-full">
                                <input 
                                  type="file"
                                  accept="image/*"
                                  onChange={(e) => handleStepImageUpload(index, e)}
                                  className="hidden"
                                  id={`step-upload-${index}`}
                                />
                                <label 
                                  htmlFor={`step-upload-${index}`}
                                  className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl border-2 border-dashed border-slate-200 hover:border-academic-blue hover:bg-blue-50 cursor-pointer transition-all bg-white"
                                >
                                  <Upload size={18} className="text-slate-400" />
                                  <span className="text-sm text-slate-600 font-medium">
                                    {step.image ? 'Change Image' : 'Upload Image'}
                                  </span>
                                </label>
                              </div>
                              {step.image && (
                                <div className="relative w-20 h-20 rounded-lg overflow-hidden border border-slate-200 shrink-0">
                                  <img src={step.image} alt={`Step ${index + 1}`} className="w-full h-full object-cover" />
                                  <button 
                                    type="button"
                                    onClick={() => {
                                      const newSteps = [...(form.steps || [])];
                                      newSteps[index] = { ...newSteps[index], image: '' };
                                      setForm(prev => ({ ...prev, steps: newSteps }));
                                    }}
                                    className="absolute top-0 right-0 bg-red-500 text-white p-0.5 rounded-bl-lg"
                                  >
                                    <X size={12} />
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                    
                    {(!form.steps || form.steps.length === 0) && (
                      <div className="text-center py-8 border-2 border-dashed border-slate-100 rounded-2xl text-slate-400 italic text-sm">
                        No steps added yet. Click "Add Step" to create a guide.
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-3 p-4 bg-yellow-50/50 border border-academic-gold/20 rounded-xl">
                  <input 
                    type="checkbox"
                    id="featured"
                    className="w-5 h-5 rounded border-slate-300 text-academic-gold focus:ring-academic-gold"
                    checked={form.featured}
                    onChange={e => setForm({...form, featured: e.target.checked})}
                  />
                  <label htmlFor="featured" className="text-sm font-bold text-slate-700 flex items-center gap-2 cursor-pointer">
                    <Star size={16} className={form.featured ? "text-academic-gold" : "text-slate-400"} fill={form.featured ? "currentColor" : "none"} />
                    Mark as Featured Update
                  </label>
                  <p className="text-[10px] text-slate-500 ml-auto italic">Featured updates appear at the top of the home page</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Start Date</label>
                    <input 
                      type="date" 
                      className="w-full p-2 text-sm border rounded-lg" 
                      value={form.startDate || ''}
                      onChange={e => setForm({...form, startDate: e.target.value})} 
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">End Date</label>
                    <input 
                      type="date" 
                      className="w-full p-2 text-sm border rounded-lg" 
                      value={form.endDate || ''}
                      onChange={e => setForm({...form, endDate: e.target.value})} 
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Update Date</label>
                    <input 
                      type="date" 
                      className="w-full p-2 text-sm border rounded-lg" 
                      value={form.updateDate || ''}
                      onChange={e => setForm({...form, updateDate: e.target.value})} 
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Release Date</label>
                    <input 
                      type="date" 
                      className="w-full p-2 text-sm border rounded-lg" 
                      value={form.releaseDate || ''}
                      onChange={e => setForm({...form, releaseDate: e.target.value})} 
                    />
                  </div>
                </div>

                <button 
                  type="submit"
                  disabled={submitting}
                  className="w-full bg-academic-blue hover:bg-blue-800 text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-100 flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-50"
                >
                  {submitting ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      {editingId ? <Save size={20} /> : <CheckCircle size={20} />}
                      <span>{editingId ? 'Save Changes' : 'Publish Update'}</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Sidebar / Recent Section */}
          <div className="space-y-6">
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
              <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                <AlertCircle size={18} className="text-academic-gold" />
                Quick Stats
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <p className="text-xs font-bold text-slate-400 uppercase mb-1">Total Updates</p>
                  <p className="text-2xl font-bold text-academic-blue">{updates.length}</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <p className="text-xs font-bold text-slate-400 uppercase mb-1">Jobs</p>
                  <p className="text-2xl font-bold text-blue-600">{updates.filter(u => u.type === 'job').length}</p>
                </div>
              </div>
            </div>

            <div className="bg-academic-blue rounded-3xl p-6 text-white">
              <h3 className="font-bold mb-2">Admin Security</h3>
              <p className="text-xs text-blue-100 leading-relaxed">
                This panel is restricted to authorized administrators only. All actions are logged and secured by Firestore Security Rules.
              </p>
            </div>
          </div>
        </div>

        {/* Content Management Table */}
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-8 border-b border-slate-100">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                  <FileText size={20} className="text-academic-blue" />
                  Content Management
                </h2>
                {selectedIds.length > 0 && (
                  <motion.button
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    onClick={handleBatchDelete}
                    disabled={submitting}
                    className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-600 rounded-xl text-sm font-bold hover:bg-red-100 transition-all border border-red-100"
                  >
                    <Trash2 size={16} />
                    Delete Selected ({selectedIds.length})
                  </motion.button>
                )}
              </div>
              
              <div className="flex flex-col sm:flex-row items-center gap-4">
                <div className="flex w-full sm:w-auto gap-2">
                  <div className="relative w-full sm:w-64">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                      type="text"
                      placeholder="Search updates..."
                      className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-academic-blue outline-none text-sm"
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <button 
                    className="px-4 py-2 bg-academic-blue text-white rounded-xl text-sm font-bold hover:bg-blue-800 transition-colors flex items-center gap-2 whitespace-nowrap"
                    onClick={() => {
                      // Search is already real-time, but this gives visual feedback
                      const input = document.querySelector('input[placeholder="Search updates..."]') as HTMLInputElement;
                      if (input) input.focus();
                    }}
                  >
                    Search
                  </button>
                </div>
                
                <div className="relative w-full sm:w-40">
                  <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <select 
                    className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-academic-blue outline-none text-sm bg-white appearance-none"
                    value={filterType}
                    onChange={e => setFilterType(e.target.value)}
                  >
                    <option value="all">All Types</option>
                    <option value="job">Jobs</option>
                    <option value="admit_card">Admit Cards</option>
                    <option value="result">Results</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100">
                  <th className="px-6 py-4 w-12">
                    <button 
                      onClick={toggleSelectAll}
                      className="text-slate-400 hover:text-academic-blue transition-colors"
                    >
                      {selectedIds.length === filteredAndSortedUpdates.length && filteredAndSortedUpdates.length > 0 ? (
                        <CheckSquare size={20} className="text-academic-blue" />
                      ) : (
                        <Square size={20} />
                      )}
                    </button>
                  </th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-academic-blue transition-colors" onClick={() => toggleSort('title')}>
                    <div className="flex items-center gap-2">
                      Title
                      {sortField === 'title' ? (sortDirection === 'asc' ? <ArrowUp size={14} /> : <ArrowDown size={14} />) : <ArrowUpDown size={14} />}
                    </div>
                  </th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-academic-blue transition-colors" onClick={() => toggleSort('type')}>
                    <div className="flex items-center gap-2">
                      Type
                      {sortField === 'type' ? (sortDirection === 'asc' ? <ArrowUp size={14} /> : <ArrowDown size={14} />) : <ArrowUpDown size={14} />}
                    </div>
                  </th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-academic-blue transition-colors" onClick={() => toggleSort('organization')}>
                    <div className="flex items-center gap-2">
                      Organization
                      {sortField === 'organization' ? (sortDirection === 'asc' ? <ArrowUp size={14} /> : <ArrowDown size={14} />) : <ArrowUpDown size={14} />}
                    </div>
                  </th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-academic-blue transition-colors" onClick={() => toggleSort('createdAt')}>
                    <div className="flex items-center gap-2">
                      Created
                      {sortField === 'createdAt' ? (sortDirection === 'asc' ? <ArrowUp size={14} /> : <ArrowDown size={14} />) : <ArrowUpDown size={14} />}
                    </div>
                  </th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-center">Featured</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredAndSortedUpdates.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-12 text-center text-slate-400 italic">
                      No updates found matching your criteria
                    </td>
                  </tr>
                ) : (
                  filteredAndSortedUpdates.map((update) => (
                    <tr key={update.id} className={`hover:bg-slate-50/50 transition-colors group ${selectedIds.includes(update.id) ? 'bg-blue-50/30' : ''}`}>
                      <td className="px-6 py-4">
                        <button 
                          onClick={() => toggleSelect(update.id)}
                          className="text-slate-300 hover:text-academic-blue transition-colors"
                        >
                          {selectedIds.includes(update.id) ? (
                            <CheckSquare size={20} className="text-academic-blue" />
                          ) : (
                            <Square size={20} />
                          )}
                        </button>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          {update.thumbnail && (
                            <div className="w-10 h-10 rounded-lg overflow-hidden border border-slate-200 shrink-0">
                              <img src={update.thumbnail} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            </div>
                          )}
                          <div className="flex flex-col">
                            <span className="text-sm font-bold text-slate-700 line-clamp-1">{update.title}</span>
                            <span className="text-[10px] text-slate-400 font-bold uppercase">{update.category}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          update.type === 'job' ? 'bg-blue-50 text-blue-600' :
                          update.type === 'admit_card' ? 'bg-yellow-50 text-academic-gold' :
                          'bg-green-50 text-green-600'
                        }`}>
                          {update.type.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm text-slate-600">{update.organization}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm text-slate-500">
                          {formatDate(update.createdAt)}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <button
                          onClick={() => handleToggleFeatured(update.id, !!update.featured)}
                          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-academic-gold focus:ring-offset-2 ${
                            update.featured ? 'bg-academic-gold' : 'bg-slate-200'
                          }`}
                          title={update.featured ? "Remove from featured" : "Mark as featured"}
                        >
                          <span
                            className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                              update.featured ? 'translate-x-6' : 'translate-x-1'
                            }`}
                          />
                        </button>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {update.officialUrl && (
                            <a 
                              href={update.officialUrl} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="p-2 text-slate-400 hover:text-academic-blue transition-colors"
                              title="View Official Link"
                            >
                              <ExternalLink size={16} />
                            </a>
                          )}
                          <button 
                            onClick={() => handleEdit(update)}
                            className="p-2 text-slate-400 hover:text-academic-blue transition-colors"
                            title="Edit Update"
                          >
                            <Edit size={16} />
                          </button>
                          <button 
                            onClick={() => handleDelete(update.id)}
                            className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                            title="Delete Update"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {/* Modals */}
      <AnimatePresence>
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowDeleteConfirm(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-3xl shadow-2xl border border-slate-200 max-w-md w-full overflow-hidden"
            >
              <div className="p-8 text-center">
                <div className="w-20 h-20 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Trash2 size={40} />
                </div>
                <h3 className="text-2xl font-serif font-bold text-slate-800 mb-2">Confirm Delete</h3>
                <p className="text-slate-500 mb-8">
                  {isBatchDelete 
                    ? `Are you sure you want to delete ${selectedIds.length} selected updates? This action cannot be undone.`
                    : "Are you sure you want to delete this update? This action cannot be undone."}
                </p>
                <div className="flex flex-col sm:flex-row gap-3">
                  <button
                    onClick={() => {
                      setShowDeleteConfirm(false);
                      setDeleteId(null);
                      setIsBatchDelete(false);
                    }}
                    className="flex-1 px-6 py-3 bg-slate-100 text-slate-600 font-bold rounded-2xl hover:bg-slate-200 transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={confirmDelete}
                    disabled={submitting}
                    className="flex-1 px-6 py-3 bg-red-600 text-white font-bold rounded-2xl hover:bg-red-700 shadow-lg shadow-red-100 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {submitting ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <Trash2 size={18} />
                    )}
                    Delete Now
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {showPreview && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowPreview(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-3xl shadow-2xl w-full max-w-2xl max-h-[80vh] overflow-hidden flex flex-col"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                  <Eye size={22} className="text-academic-blue" />
                  Guide Preview
                </h3>
                <button 
                  onClick={() => setShowPreview(false)}
                  className="p-2 hover:bg-slate-200 rounded-full transition-colors"
                >
                  <X size={20} className="text-slate-500" />
                </button>
              </div>
              
              <div className="p-8 overflow-y-auto custom-scrollbar">
                <div className="space-y-0 relative">
                  <div className="absolute left-[15px] top-4 bottom-4 w-0.5 bg-slate-100 hidden md:block"></div>
                  
                  {form.steps?.map((step, index) => (
                    <div key={index} className="relative pl-0 md:pl-12 pb-12 last:pb-0">
                      <div className="absolute left-0 md:left-[0px] top-0 w-8 h-8 bg-academic-blue text-white rounded-full flex items-center justify-center font-bold shadow-md z-10">
                        {index + 1}
                      </div>
                      
                      <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm hover:shadow-md transition-all">
                        <p className="text-slate-700 leading-relaxed whitespace-pre-wrap mb-4">
                          {step.text || <span className="text-slate-300 italic">No instructions provided for this step.</span>}
                        </p>
                        
                        {step.image && (
                          <div className="rounded-xl overflow-hidden border border-slate-100 bg-slate-50">
                            <img 
                              src={step.image} 
                              alt={`Step ${index + 1}`} 
                              className="w-full h-auto max-h-[400px] object-contain mx-auto"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="p-6 border-t border-slate-100 bg-slate-50/50 flex justify-end">
                <button 
                  onClick={() => setShowPreview(false)}
                  className="px-6 py-2 bg-academic-blue text-white font-bold rounded-xl hover:bg-blue-800 transition-all"
                >
                  Close Preview
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
