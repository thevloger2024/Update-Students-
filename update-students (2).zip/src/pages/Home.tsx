import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Header } from '../components/Header';
import { CategoryTray } from '../components/CategoryTray';
import { StateSelector } from '../components/StateSelector';
import { UpdateSection } from '../components/UpdateSection';
import { FeaturedUpdates } from '../components/FeaturedUpdates';
import { UpdateCard, UpdateData } from '../components/UpdateCard';
import { collection, onSnapshot, query, orderBy, doc, getDoc, setDoc } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { StatePromptModal } from '../components/StatePromptModal';
import { toast } from 'sonner';
import { LayoutDashboard, Filter, Search } from 'lucide-react';

export function Home() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedState, setSelectedState] = useState<string | null>(null);
  const [updates, setUpdates] = useState<UpdateData[]>([]);
  const [loading, setLoading] = useState(true);
  const [showPrompt, setShowPrompt] = useState(false);
  const [pendingState, setPendingState] = useState<string | null>(null);
  const [user, setUser] = useState<any>(null);
  
  const location = useLocation();
  const navigate = useNavigate();
  const searchParams = new URLSearchParams(location.search);
  const searchQuery = searchParams.get('q')?.toLowerCase() || '';

  // Listen for auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        loadUserPreference(currentUser.uid);
      }
    });
    return () => unsubscribe();
  }, []);

  const loadUserPreference = async (uid: string) => {
    try {
      const prefDoc = await getDoc(doc(db, 'users', uid, 'preferences', 'general'));
      if (prefDoc.exists()) {
        const data = prefDoc.data();
        if (data.preferredState) {
          setSelectedState(data.preferredState);
        }
      }
    } catch (error) {
      console.error("Error loading preferences:", error);
    }
  };

  const handleStateSelect = (state: string | null) => {
    setSelectedState(state);
    
    // Only prompt if user is logged in, selecting a non-null state, 
    // and it's different from current selection
    if (user && state && state !== selectedState) {
      setPendingState(state);
      setShowPrompt(true);
    }
  };

  const saveStatePreference = async () => {
    if (!user || !pendingState) return;
    
    try {
      await setDoc(doc(db, 'users', user.uid, 'preferences', 'general'), {
        preferredState: pendingState,
        updatedAt: Date.now()
      });
      toast.success(`Preference saved: ${pendingState}`);
    } catch (error) {
      console.error("Error saving preference:", error);
      toast.error("Failed to save preference");
    } finally {
      setShowPrompt(false);
      setPendingState(null);
    }
  };

  useEffect(() => {
    const q = query(collection(db, 'updates'), orderBy('createdAt', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const updatesData: UpdateData[] = [];
      snapshot.forEach((doc) => {
        updatesData.push({ id: doc.id, ...doc.data() } as UpdateData);
      });
      setUpdates(updatesData);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching updates:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const filteredUpdates = updates
    .map((update) => {
      let score = 0;
      if (searchQuery) {
        const title = update.title.toLowerCase();
        const org = update.organization.toLowerCase();
        const desc = update.description.toLowerCase();
        const cat = update.category.toLowerCase();
        const queryWords = searchQuery.split(/\s+/).filter(Boolean);

        // Full phrase matches
        if (title.includes(searchQuery)) score += 20;
        if (desc.includes(searchQuery)) score += 10;
        if (org.includes(searchQuery)) score += 5;
        if (cat.includes(searchQuery)) score += 5;

        // Individual word matches
        queryWords.forEach(word => {
          if (title.includes(word)) score += 5;
          if (desc.includes(word)) score += 2;
          if (org.includes(word)) score += 1;
          if (cat.includes(word)) score += 1;
          
          // Exact word match bonus
          const titleWords = title.split(/\W+/);
          if (titleWords.includes(word)) score += 5;
        });

        // Exact title match
        if (title === searchQuery) score += 50;
        // Starts with query
        if (title.startsWith(searchQuery)) score += 10;
      } else {
        score = 1;
      }

      return { ...update, score };
    })
    .filter((update) => {
      const categoryMatch = selectedCategory ? update.category === selectedCategory : true;
      const updateState = update.state.toLowerCase();
      const stateMatch = selectedState 
        ? updateState === selectedState.toLowerCase() || updateState === 'all' || updateState === 'all india' 
        : true;
      const searchMatch = searchQuery ? update.score > 0 : true;

      return categoryMatch && stateMatch && searchMatch;
    })
    .sort((a, b) => {
      if (searchQuery) {
        if (b.score !== a.score) return b.score - a.score;
      }
      return b.createdAt - a.createdAt;
    });

  const latestJobs = filteredUpdates.filter((u) => u.type === 'job');
  const admitCards = filteredUpdates.filter((u) => u.type === 'admit_card');
  const results = filteredUpdates.filter((u) => u.type === 'result');
  const scholarships = filteredUpdates.filter((u) => u.type === 'scholarship');
  const featuredUpdates = filteredUpdates.filter((u) => u.featured);

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <Header />
      <CategoryTray selectedCategory={selectedCategory} onSelectCategory={setSelectedCategory} />
      
      <main className="pb-20">
        <StateSelector selectedState={selectedState} onSelectState={handleStateSelect} />
        
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-academic-blue"></div>
          </div>
        ) : (
          <>
            {selectedCategory ? (
              <section className="max-w-7xl mx-auto px-4 py-8">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
                  <div className="flex items-center gap-4">
                    <div className="p-4 bg-academic-blue text-white rounded-2xl shadow-lg shadow-blue-100">
                      <LayoutDashboard size={28} />
                    </div>
                    <div>
                      <h2 className="text-3xl font-serif font-bold text-academic-blue">
                        {selectedCategory} Updates
                      </h2>
                      <p className="text-slate-500 font-medium">Latest notifications and updates for {selectedCategory}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 bg-white rounded-xl border border-slate-200 text-slate-500 text-sm font-bold shadow-sm self-start md:self-center">
                    <Filter size={16} />
                    <span>{filteredUpdates.length} Updates Found</span>
                  </div>
                </div>

                {filteredUpdates.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {filteredUpdates.map((update) => (
                      <UpdateCard key={update.id} update={update} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-20 bg-white rounded-3xl border-2 border-dashed border-slate-100">
                    <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Search size={32} className="text-slate-300" />
                    </div>
                    <p className="text-slate-400 font-medium italic">No updates found for {selectedCategory} at the moment.</p>
                    <button 
                      onClick={() => setSelectedCategory(null)}
                      className="mt-4 text-academic-blue font-bold hover:underline"
                    >
                      View all updates
                    </button>
                  </div>
                )}
              </section>
            ) : (
              <>
                {!searchQuery && (
                  <FeaturedUpdates updates={featuredUpdates} />
                )}
                <UpdateSection title="Latest Jobs" type="job" updates={latestJobs} />
                <UpdateSection title="Admit Card" type="admit_card" updates={admitCards} />
                <UpdateSection title="Results" type="result" updates={results} />
                <UpdateSection title="Scholarships" type="scholarship" updates={scholarships} />
              </>
            )}
          </>
        )}
      </main>

      <StatePromptModal 
        isOpen={showPrompt}
        stateName={pendingState || ''}
        onConfirm={saveStatePreference}
        onCancel={() => {
          setShowPrompt(false);
          setPendingState(null);
        }}
      />
    </div>
  );
}
