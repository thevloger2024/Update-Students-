import React, { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { auth } from '../firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Lock, LogIn, LogOut, Shield, Settings, Users, Database, ArrowLeft } from 'lucide-react';
import { signInWithGoogle, logOut } from '../firebase';

const ADMIN_EMAIL = "thevloger2024@gmail.com";

export function AdminFeaturesPage() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-academic-blue"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 rounded-3xl shadow-xl border border-slate-200 max-w-md w-full text-center"
        >
          <div className="w-20 h-20 bg-blue-50 text-academic-blue rounded-full flex items-center justify-center mx-auto mb-6">
            <Lock size={40} />
          </div>
          <h1 className="text-2xl font-serif font-bold text-academic-blue mb-2">Admin Login</h1>
          <p className="text-slate-500 mb-8">Please sign in with your administrator account to access this panel.</p>
          <button 
            onClick={signInWithGoogle}
            className="w-full bg-academic-blue hover:bg-blue-800 text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-100 flex items-center justify-center gap-3 transition-all active:scale-95"
          >
            <LogIn size={20} />
            <span>Sign in with Google</span>
          </button>
        </motion.div>
      </div>
    );
  }

  if (user.email !== ADMIN_EMAIL) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 rounded-3xl shadow-xl border border-slate-200 max-w-md w-full text-center"
        >
          <div className="w-20 h-20 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <Shield size={40} className="text-red-500" />
          </div>
          <h1 className="text-2xl font-serif font-bold text-red-600 mb-2">Access Denied</h1>
          <p className="text-slate-500 mb-8">
            The account <span className="font-bold text-slate-800">{user.email}</span> does not have administrator privileges.
          </p>
          <div className="space-y-4">
            <button 
              onClick={logOut}
              className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-4 rounded-2xl flex items-center justify-center gap-3 transition-all active:scale-95"
            >
              <LogOut size={20} />
              <span>Sign out</span>
            </button>
            <button 
              onClick={() => navigate('/')}
              className="w-full text-academic-blue font-bold py-2 hover:underline transition-all"
            >
              Back to Home
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  const features = [
    {
      title: "User Management",
      description: "Manage user roles, permissions, and account status.",
      icon: Users,
      color: "bg-purple-50 text-purple-600",
      status: "Coming Soon"
    },
    {
      title: "Content Moderation",
      description: "Review and moderate user-submitted content and feedback.",
      icon: Database,
      color: "bg-blue-50 text-blue-600",
      status: "Coming Soon"
    },
    {
      title: "System Settings",
      description: "Configure global application settings and maintenance mode.",
      icon: Settings,
      color: "bg-orange-50 text-orange-600",
      status: "Coming Soon"
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-academic-blue text-white rounded-2xl shadow-lg shadow-blue-100">
              <Shield size={28} />
            </div>
            <div>
              <h1 className="text-3xl font-serif font-bold text-academic-blue">Admin Features</h1>
              <p className="text-slate-500">Advanced management tools and settings</p>
            </div>
          </div>
          <button 
            onClick={() => navigate('/admin')}
            className="flex items-center gap-2 text-slate-500 hover:text-academic-blue font-bold transition-colors"
          >
            <ArrowLeft size={20} />
            <span>Back to Dashboard</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200 hover:shadow-md transition-shadow relative overflow-hidden group"
              >
                <div className={`w-14 h-14 ${feature.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  <Icon size={28} />
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-3">{feature.title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed mb-6">
                  {feature.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 bg-slate-50 px-3 py-1 rounded-full">
                    {feature.status}
                  </span>
                </div>
                <div className="absolute top-0 right-0 w-24 h-24 bg-slate-50 -mr-12 -mt-12 rounded-full opacity-50 group-hover:scale-150 transition-transform" />
              </motion.div>
            );
          })}
        </div>

        <div className="mt-12 p-8 bg-academic-blue rounded-3xl text-white relative overflow-hidden">
          <div className="relative z-10">
            <h2 className="text-2xl font-serif font-bold mb-4">Future Roadmap</h2>
            <p className="text-blue-100 max-w-2xl leading-relaxed">
              We are working on expanding the admin capabilities to include real-time analytics, automated notification broadcasting, and advanced data export tools. Stay tuned for updates!
            </p>
          </div>
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 -mr-32 -mt-32 rounded-full" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 -ml-16 -mb-16 rounded-full" />
        </div>
      </main>
    </div>
  );
}
